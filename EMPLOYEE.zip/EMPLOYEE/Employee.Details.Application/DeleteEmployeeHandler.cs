﻿using Employee.Details.Infrastructure.Data;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee.Details.Application
{
    public class DeleteEmployeeHandler : IRequestHandler<DeleteEmployee, List<EmployeeDto>>
    {
 
        private readonly EmployeeContext _context;

        public DeleteEmployeeHandler(EmployeeContext context)
        {
            _context = context;
        }

        public Task<List<EmployeeDto>> Handle(DeleteEmployee request, CancellationToken cancellationToken)
        {
            var employee = _context.employees.Find(request.Id);
            _context.employees.Remove(employee);
            _context.SaveChanges();


            var employeeDto = new EmployeeDto
            {
                Id = request.Id,
                name = employee.name,
                age = employee.age
            };
            return Task.FromResult(new List<EmployeeDto> { employeeDto });

        }
    }
}