﻿using Employee.Details.Domain;
using Employee.Details.Infrastructure.Data;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee.Details.Application
{
    public class AddEmployeeCommandHandler : IRequestHandler<AddEmployeecommand, int>
    {
        public readonly EmployeeContext _context;

        public AddEmployeeCommandHandler(EmployeeContext context)
        {
            _context = context;
        }
        public async Task<int> Handle(AddEmployeecommand request, CancellationToken cancellationToken)
        {
            Employees obj = new Employees();
            obj.age = request.age; 
            obj.name = request.Name;
            _context.employees.Add(obj);
            return await _context.SaveChangesAsync();

        }

    }
}
