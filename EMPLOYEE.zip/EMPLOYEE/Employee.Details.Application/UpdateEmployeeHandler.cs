﻿using Employee.Details.Domain;
using Employee.Details.Infrastructure.Data;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee.Details.Application
{
    public class UpdateEmployeeHandler : IRequestHandler<UpdateEmployee, List<EmployeeDto>>
    {
        private readonly EmployeeContext _context;

        public UpdateEmployeeHandler(EmployeeContext context)
        {
            _context = context;
        }

        public Task<List<EmployeeDto>> Handle(UpdateEmployee request, CancellationToken cancellationToken)
        {
            var employee = _context.employees.Find(request.id);
            employee.name = request.employees.name;
            employee.age= request.employees.age;

            _context.employees.Update(employee);
            _context.SaveChanges();


            var employeeDto = new EmployeeDto
            {
                Id = request.id,
                name = employee.name,
                age = employee.age
            };
            return Task.FromResult(new List<EmployeeDto> { employeeDto });
        }
}
    }