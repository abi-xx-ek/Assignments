﻿using Employee.Details.Domain;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee.Details.Application
{
    public class AddEmployeecommand:IRequest<int>
    {
        public string Name { get; set; }
        public int age { get; set; }
    }
}
