﻿using Employee.Details.Domain;
using Employee.Details.Infrastructure.Data;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee.Details.Application
{
    public class GetEmployeeQueryHandler : IRequestHandler<GetEmployeeQuery, List<Employees>>
    {
        private readonly EmployeeContext _context;

        public GetEmployeeQueryHandler(EmployeeContext context)
        {
            _context = context;
        }

        public async Task<List<Employees>> Handle(GetEmployeeQuery request, CancellationToken cancellationToken)
        {
            var re = await Task.Run(() =>
            {
                List<Employees> result = new List<Employees>();
                var Employees = _context.employees;
                foreach (var employee in Employees)
                {
                    result.Add(employee);
                }
                return result;
            });
            return re;
        }
    }

}
