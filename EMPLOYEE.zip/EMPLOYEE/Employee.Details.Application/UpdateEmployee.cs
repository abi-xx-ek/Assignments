﻿using Employee.Details.Domain;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee.Details.Application
{
    public class UpdateEmployee:IRequest<List<EmployeeDto>>
    {
        public int id { get; set; }
       public EmployeeDto employees { get; set; }
    }
}
