﻿using Employee.Details.Application;
using Employee.Details.Domain;
using MediatR;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Employee.Details.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Employee : ControllerBase
        

    {
        private readonly IMediator _mediator;

        public Employee(IMediator mediator)
        {
            _mediator = mediator;
        }
       
        [HttpGet]
        public async Task<List<Employees>> GetAll()
        {
            var query = new GetEmployeeQuery();
            return await _mediator.Send(query);
        }
        [HttpPost]
        public async Task<int> AddEmployee(AddEmployeecommand command)
        {
            return await _mediator.Send(command);
        }

        [HttpPut("{id}")]
        public async Task<List<EmployeeDto>> Put(int id, [FromBody] EmployeeDto emp)
        {
            UpdateEmployee query= new UpdateEmployee();
            query.id = id;
            query.employees= emp;
            return await _mediator.Send(query);
        }



        // DELETE api/<Employee>/5
        [HttpDelete("{id}")]
        public async Task<List<EmployeeDto>> Delete(int id)
        {
            DeleteEmployee query = new DeleteEmployee();
            query.Id = id;
            return await _mediator.Send(query);

        }
    }
}
